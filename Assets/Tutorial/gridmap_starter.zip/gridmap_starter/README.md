# GridMap project starter

Used by the "Using GridMaps" tutorial:

https://docs.godotengine.org/en/latest/tutorials/3d/using_gridmaps.html
